The programs available in this directory are for 
raspberry pi hardware (we are using 4b+)

The programs are commented to give a clear idea to 
a user about the usage.

The programs that are prefixed with esp are the programs 
where the ESPcam module is used as hardware for image-processing
(these programs can be tweaked for other hardwares)

The type of input we take for both of these hardware is different.

All the other programs are essentially those where raspberry pi camera (rev1.3) 
is used for image-processing 
