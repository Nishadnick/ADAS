import cv2
import numpy as np
#Atlast this works esp3!!
# Set the URL of the ESP32-CAM video feed
url = 'http://192.168.43.236:81/stream'

# Create a VideoCapture object
cap = cv2.VideoCapture(url)

# Check if the video capture object is successfully opened
if not cap.isOpened():
    print('Failed to open video feed.')
    exit()

# Read and display video frames
while True:
    ret, frame = cap.read()
    if not ret:
        print('Failed to receive frame.')
        break

    # Convert the frame to the HSV color space
    hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # Define the lower and upper bounds for red color in HSV
    lower_red = np.array([0, 120, 70])
    upper_red = np.array([10, 255, 255])
    mask1 = cv2.inRange(hsv_frame, lower_red, upper_red)

    lower_red = np.array([170, 120, 70])
    upper_red = np.array([180, 255, 255])
    mask2 = cv2.inRange(hsv_frame, lower_red, upper_red)

    # Combine the masks
    mask = mask1 + mask2

    # Find contours of the red areas
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Iterate over the contours and draw bounding boxes
    for contour in contours:
        # Calculate bounding box coordinates
        x, y, w, h = cv2.boundingRect(contour)
        area = cv2.contourArea(contour)

        # Draw the bounding box around the red area
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        if area > 500:
            print("COLOUR RED DETEDE")
    # Display the frame with the bounding boxes
    cv2.imshow('Red Area Detection', frame)

    # Press 'q' to exit the program
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture object and close the OpenCV windows
cap.release()
cv2.destroyAllWindows()
