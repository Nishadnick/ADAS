import cv2
from imutils.video import VideoStream

# Set the URL of the ESP32-CAM video feed
url = 'http://192.168.43.236:81/stream'

# Create a VideoStream object
vs = VideoStream(url).start()

# Wait for the camera to start
# (You can adjust this delay based on your camera)
cv2.waitKey(2000)

# Read and display video frames
while True:
    frame = vs.read()
    if frame is None:
        print('Failed to receive frame.')
        break

    # Display the frame
    cv2.imshow('ESP32-CAM Video Feed', frame)

    # Press 'q' to exit the program
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the resources
cv2.destroyAllWindows()
vs.stop()
