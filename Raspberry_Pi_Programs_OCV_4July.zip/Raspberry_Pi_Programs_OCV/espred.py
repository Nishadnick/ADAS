import cv2
import numpy as np

# Set the URL of the ESP32-CAM video feed
url = 'http://192.168.43.236:81/stream'

# Create a VideoCapture object
cap = cv2.VideoCapture(url)

# Check if the video capture object is successfully opened
if not cap.isOpened():
    print('Failed to open video feed.')
    exit()

# Read and display video frames
while True:
    ret, frame = cap.read()
    if not ret:
        print('Failed to receive frame.')
        break

    # Convert the frame to the HSV color space
    hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # Define the lower and upper bounds for red color in HSV
    lower_red = np.array([0, 120, 70])
    upper_red = np.array([10, 255, 255])
    mask1 = cv2.inRange(hsv_frame, lower_red, upper_red)

    lower_red = np.array([170, 120, 70])
    upper_red = np.array([180, 255, 255])
    mask2 = cv2.inRange(hsv_frame, lower_red, upper_red)

    # Combine the masks
    mask = mask1 + mask2

    # Apply the mask to the original frame
    result = cv2.bitwise_and(frame, frame, mask=mask)

    # Display the frame and the color-detected result
    cv2.imshow('Original Frame', frame)
    cv2.imshow('Color Detection', result)

    # Press 'q' to exit the program
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture object and close the OpenCV windows
cap.release()
cv2.destroyAllWindows()
