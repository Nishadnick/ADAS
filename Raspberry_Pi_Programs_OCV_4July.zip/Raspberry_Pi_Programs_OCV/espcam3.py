import cv2
from mjpegclient import MJPEGClient

# Set the URL of the ESP32-CAM video feed
url = 'http://192.168.43.236:81/stream'

# Create an MJPEG client object
client = MJPEGClient(url)

# Start the video capture
client.open()

# Read and display video frames
while True:
    frame = client.read()
    if frame is None:
        print('Failed to receive frame.')
        break

    # Display the frame
    cv2.imshow('ESP32-CAM Video Feed', frame)

    # Press 'q' to exit the program
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the resources
client.close()
cv2.destroyAllWindows()
