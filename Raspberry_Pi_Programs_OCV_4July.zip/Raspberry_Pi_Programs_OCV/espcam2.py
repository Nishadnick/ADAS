import cv2

# Set the URL of the ESP32-CAM video feed
#url = 'http://<ESP32_CAM_IP_ADDRESS>/stream'
#wowowo working for esp3!
url = 'http://192.168.43.236:81/stream'

# Create a VideoCapture object
cap = cv2.VideoCapture(url)

# Check if the video capture object is successfully opened
if not cap.isOpened():
    print('Failed to open video feed.')
    exit()

# Read and display video frames
while True:
    ret, frame = cap.read()
    if not ret:
        print('Failed to receive frame.')
        break
    
    # Display the frame
    cv2.imshow('ESP32-CAM Video Feed', frame)
    
    # Press 'q' to exit the program
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture object and close the OpenCV windows
cap.release()
cv2.destroyAllWindows()
